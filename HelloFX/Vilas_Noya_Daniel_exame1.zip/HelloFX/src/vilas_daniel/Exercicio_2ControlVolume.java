package vilas_daniel;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.converter.NumberStringConverter;

public class Exercicio_2ControlVolume extends Application {
	
	public void start(Stage stage) throws Exception {

		Pane root = new Pane();
		
		Slider sliderH = new Slider(0, 100, 50);
		
		IntegerProperty numero1 = new  SimpleIntegerProperty();
		
		Label lbl1 = new Label();
		Label lbl2 = new Label();
		
		numero1.bind(sliderH.valueProperty());
		lbl2.textProperty().bindBidirectional(numero1, new NumberStringConverter());
		
				
		sliderH.setShowTickLabels(true);
		sliderH.setMajorTickUnit(100);
		sliderH.relocate(80, 80);
		lbl2.relocate(140,40);
		
		root.getChildren().addAll(lbl1, lbl2, sliderH);
	
		// Creamos la escena
		Scene scene = new Scene(root, 300, 250);
		stage.setTitle("Control de volume");
		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] args) {
		launch();
	}
}
