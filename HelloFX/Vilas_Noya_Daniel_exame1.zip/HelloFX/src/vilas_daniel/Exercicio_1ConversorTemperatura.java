package vilas_daniel;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Exercicio_1ConversorTemperatura extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {

		VBox root = new VBox();

		HBox primero = new HBox();
		HBox segundo = new HBox();
		HBox terceiro = new HBox();
		HBox cuarto = new HBox();

		// Creamos los label
		Label celsius = new Label("Celsius:");
		Label fahrenheit = new Label("Fahrenheit:");
		Label rslt = new Label("");


		// Creamos textfield
		TextField celsiusfield = new TextField();
		TextField fahrenheitfield = new TextField();

		celsiusfield.setPromptText("Introduce C: ");
		fahrenheitfield.setPromptText("Introduce F: ");

		// Celsius a Fahrenheit: F = (C × 9/5) + 32
		// Fahrenheit a Celsius: C = (F - 32) × 5/9

		// Creamos PRIMER boton y sus acciones
		Button btn1 = new Button("C a F");
		btn1.setOnAction(e -> {

			try {

				double ncelsius = Double.parseDouble(celsiusfield.getText());
				double resultado1 = (ncelsius * 9 / 5) + 32;

				rslt.setText(ncelsius + "ºC = " + +resultado1 + "ºF");
				rslt.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, null, null)));
				;
				fahrenheitfield.setText(String.valueOf(resultado1));

			} catch (NumberFormatException e1) {

				rslt.setText("Introduce un valor válido");
				rslt.setBackground(new Background(new BackgroundFill(Color.RED, null, null)));
				;
			}
		});
		
		
		// Creamos SEGUNDO boton y sus acciones
		Button btn2 = new Button("F a C");
		btn2.setOnAction(e -> {

			try {

				double nfahrenheit = Double.parseDouble(fahrenheitfield.getText());
				double resultado2 = (nfahrenheit - 32) * 5/9;

				rslt.setText(nfahrenheit + "ºF = " + +resultado2 + "ºC");
				rslt.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, null, null)));
				;
				celsiusfield.setText(String.valueOf(resultado2));

			} catch (NumberFormatException e2) {

				rslt.setText("Introduce un valor válido");
				rslt.setBackground(new Background(new BackgroundFill(Color.RED, null, null)));
				;
			}
		});
		
		// Creamos TERCER boton y sus acciones
		Button btn3 = new Button("Limpar");
		btn3.setOnAction(e -> {
		
		//Para eliminar los números al pulsar limpar
		celsiusfield.setText(null);
		fahrenheitfield.setText(null);
		rslt.setText(null);
		});
		
		root.setSpacing(10);
		primero.setSpacing(10);
		segundo.setSpacing(10);
		terceiro.setSpacing(10);

		// Indica el orden
		root.getChildren().addAll(primero, segundo, terceiro, cuarto);
		primero.getChildren().addAll(celsius, celsiusfield);
		segundo.getChildren().addAll(fahrenheit, fahrenheitfield);
		terceiro.getChildren().addAll(btn1, btn2, btn3);
		cuarto.getChildren().addAll(rslt );

		// Para que me aparezca la escena
		Scene scene = new Scene(root, 300, 200);
		stage.setTitle("Conversor de temperatura");
		stage.setScene(scene);
		stage.show();
	}

}
